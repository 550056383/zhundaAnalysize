package zd.zdcommons.analysis;

import zd.zdcommons.pojo.ResultMessage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Complete {

    //第一个规则所需要判断的字段
    private static final String[] duidstr = {"YD5-dUID","YD5-customerSiteID","YD5-customerSiteName",
            "YD5-dUName","YD5-area","YD5-Subcontractor","YD5-spectrum","YD5-nroServiceContract",
            "YD5-scenario","YD5-scenario","YD5-standingType","YD5-engineeringServiceMode",
            "YD5-contractConnection","YD5-standingType2","YD5-standard"};
    //第二个规则所需的字段
    private static final String[] icad = {"YD5-MOS-actualEndDate","YD5-productModel",
            "YD5-remoteStationType","YD5-planningNumber","YD5-tianmianTransformation","YD5-dcFuse",
            "YD5-acInduction","YD5-design","YD5-rruHardwareNumber","YD5-IC-actualEndDate"};
    //第三个规则所需字段
    private static final String[] aau = {"YD5-IC-actualEndDate","YD5-deliveryType",
            "YD5-nROPO","YD5-rruToneNumber","YD5-residentialBroadband","YD5-transmissionEquipped",
            "YD5-bbuESN","YD5-bbuSiteID","YD5-bbuSiteName","YD5-rruScenario",
            "YD5-transmissionBandwidth","YD5-nroSubcontractor"};
    //第四个规则所需字段
    private static final String[] fiveg = {"YD5-completionDate","YD5-AAU-actualEndDate"};
    //第六个规则所需字段
    private static final String[] fddanzhang = {"MIMO-transmissionAvailable4G","M1800-programNumberFDD",
            "M1800-constructionPlanFDD","M1800-whetherPlanningFDD","M1800-nmNEIDFDD","M1800-arrivalDateFDD",
            "M1800-installationFDD"};
    //第七个规则所需字段
    private static final String[] fddkt = {"M1800-installationFDD","M1800-baseStationNameFDD",
            "MIMO-transmissionBandwidthe4G"};
    //第八个规则所需字段
    private static final String[] fddjy = {"M1800-openedFDD","M1800-deliveryCompletionDateFFD"};
    //第十个规则所需字段
    private static final String[] mimoaz = {"MIMO-miMO3DID","MIMO-planningNumber",
            "MIMO-nmNEID","MIMO-openTypeStandTarget","MIMO-openTypeStand","MIMO-miMO3DGoodsQuantity"};
    //第十一个规则
    private static final String[] mimoawc = {"MIMO-installationDate",
            "MIMO-transmissionBandwidthe4G","MIMO-baseStationName"};
    //第十二个规则
    private static final String[] mimojy = {"MIMO-completionDate","MIMO-miMO3DDate"};

    /**
     * 得到错误信息和出错次数的方法
     *
     * @param s 包含判断的字段的数组
     * @param map 读取的表格数据
     * @param befolist 错误信息的集合
     * @param count 出错的次数
     * @return 返回一个map集合包含错误信息和出错次数
     */
    public static HashMap<String,Object> getCO(String [] s, Map<String, Object> map, List<String> befolist, long count) {
        List<String> list = befolist;
        for(int i = 0;i<s.length;i++) {
            if(map.get(s[i]).toString().isEmpty()) {
                list.add(s[i]);
                count++;
            }
        }
        HashMap<String,Object> hashMap = new HashMap<String ,Object>();
        hashMap.put("error", list);
        hashMap.put("count", count);
        return hashMap;
    }
    /**
     * 分析完整性的方法
     * @param resource 读取的表格数据
     * @return 返回一个结果实体类
     */
    public static ResultMessage getIntegrityCompleteAnalysize(Map<String, Object> resource){
        //结果信息的实体类
        ResultMessage r = null;
        //Listmessge
        ArrayList<String> list = new ArrayList<String>();
        //记录count数即错误数
        long count=0;
        //获取数据
        //第一个规则
        if(!resource.get("YD5-dUID").toString().isEmpty()) {
            HashMap<String,Object> map = getCO(duidstr,resource,list, count);//返回的是为空的字段的集合
            list = (ArrayList<String>) map.get("error");
            count = Long.parseLong(map.get("count").toString());
        }
        //第二个规则
        if(!resource.get("YD5-RFI-actualEndDate").toString().isEmpty()) {
            HashMap<String,Object> map = getCO(icad,resource,list, count);//返回的是为空的字段的集合
            list = (ArrayList<String>) map.get("error");
            count = Long.parseLong(map.get("count").toString());
        }
        //第三个规则
        if(!resource.get("YD5-AAU-actualEndDate").toString().isEmpty()) {
            HashMap<String,Object> map = getCO(aau,resource,list, count);//返回的是为空的字段的集合
            list = (ArrayList<String>) map.get("error");
            count = Long.parseLong(map.get("count").toString());
        }
        //第四个规则
        if(!resource.get("YD5-receptionDate").toString().isEmpty()) {
            HashMap<String,Object> map = getCO(fiveg,resource,list, count);//返回的是为空的字段的集合
            list = (ArrayList<String>) map.get("error");
            count = Long.parseLong(map.get("count").toString());
        }
        //第五个规则
        if((!resource.get("M1800-openedFDD").toString().isEmpty())&&(!resource.get("YD5-problemClassification").toString().isEmpty())) {
            list.add("YD5-problemClassification");
            count++;
        }
        if((resource.get("M1800-openedFDD").toString().isEmpty())&&(resource.get("YD5-problemClassification").toString().isEmpty())) {
            list.add("YD5-problemClassification");
            count++;
        }
        //第六个规则
        if(!resource.get("M1800-installationFDD").toString().isEmpty()) {
            HashMap<String,Object> map = getCO(fddanzhang,resource,list, count);//返回的是为空的字段的集合
            list = (ArrayList<String>) map.get("error");
            count = Long.parseLong(map.get("count").toString());
        }
        //第七个规则
        if(!resource.get("M1800-openedFDD").toString().isEmpty()) {
            HashMap<String,Object> map = getCO(fddkt,resource,list, count);//返回的是为空的字段的集合
            list = (ArrayList<String>) map.get("error");
            count = Long.parseLong(map.get("count").toString());
        }

        //第八个规则
        if(!resource.get("M1800-deliveryDateFDD").toString().isEmpty()) {
            HashMap<String,Object> map = getCO(fddjy,resource,list, count);//返回的是为空的字段的集合
            list = (ArrayList<String>) map.get("error");
            //count = (long) map.get("count");
        }
        //第九个规则
        if((!resource.get("M1800-openedFDD").toString().isEmpty())&&(!resource.get("M1800-questionClassificationFDD").toString().isEmpty())) {
            list.add("M1800-questionClassificationFDD");
            count++;
        }
        if((resource.get("M1800-openedFDD").toString().isEmpty())&&(resource.get("M1800-questionClassificationFDD").toString().isEmpty())) {
            list.add("M1800-questionClassificationFDD");
            count++;
        }
        //第十个规则
        if(!resource.get("MIMO-installationDate").toString().isEmpty()) {
            HashMap<String,Object> map = getCO(mimoaz,resource,list, count);//返回的是为空的字段的集合
            list = (ArrayList<String>) map.get("error");
            count = Long.parseLong(map.get("count").toString());
        }
        //第十一个规则
        if(!resource.get("MIMO-completionDate").toString().isEmpty()) {
            HashMap<String,Object> map = getCO(mimoawc,resource,list, count);//返回的是为空的字段的集合
            list = (ArrayList<String>) map.get("error");
            count = Long.parseLong(map.get("count").toString());
        }
        //第十二个规则
        if(!resource.get("MIMO-deliveryDate").toString().isEmpty()) {
            HashMap<String,Object> map = getCO(mimojy,resource,list, count);//返回的是为空的字段的集合
            list = (ArrayList<String>) map.get("error");
            count = Long.parseLong(map.get("count").toString());
        }
        //第十三个规则
        if((!resource.get("MIMO-completionDate").toString().isEmpty())&&(!resource.get("M1800-questionClassificationFDD").toString().isEmpty())) {
            list.add("MIMO-questionClassification");
            count++;
        }
        if((resource.get("MIMO-completionDate").toString().isEmpty())&&(resource.get("M1800-questionClassificationFDD").toString().isEmpty())) {
            list.add("MIMO-questionClassification");
            count++;
        }
        //添加最终数据
        if(list.size()>0){
	            /*r.setTError("完整性错误");
	            r.setDUID(resource.get("YD5-dUID").toString());
	            r.setDUName(resource.get("YD5-dUName").toString());*/r=new ResultMessage();
               r.setTError("完整性错误");
               System.out.println("YD5-dUID-------------------------:"+resource.get("YD5-dUID").toString());
               r.setDUID(resource.get("YD5-dUID").toString());
               r.setDUName(resource.get("YD5-dUName").toString());
               r.setMessge(list);
               r.setXcount(count);
        }
        return r;
    }

}
