package zd.zdcommons.pojo;

import lombok.Data;

import java.util.List;

@Data
public class ResultMessage {
    private String tError;
    private String dUID;
    private String dUName;
    private List<String>messge;
    private Long xcount;


    @Override
    public String toString() {
        return "ResultMessage{" +
                "tError='" + tError + '\'' +
                ", dUID='" + dUID + '\'' +
                ", dUName='" + dUName + '\'' +
                ", messge=" + messge +
                ", xcount=" + xcount +
                '}';
    }
}
