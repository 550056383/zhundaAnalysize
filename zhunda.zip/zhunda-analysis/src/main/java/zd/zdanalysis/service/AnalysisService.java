package zd.zdanalysis.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import zd.zdcommons.Utils;
import zd.zdcommons.analysis.Complete;
import zd.zdcommons.pojo.Pageto;
import zd.zdcommons.pojo.ResultMessage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class AnalysisService {

    public Pageto getAnalysis(MultipartFile shishi, MultipartFile daka) {
        Utils utils = new Utils();
        Complete c = new Complete();
        List<Map<String, Object>> maps = utils.readExcel(shishi);
        Pageto pt = new Pageto();

        //完整性计数
        long iCCount=0;
        //准确性计数
        long iACount=0;
        //逻辑性计数
        long iLCont=0;
        //信息
        List<ResultMessage> reslist=new ArrayList<ResultMessage>();
        for (Map t :maps){
            ResultMessage resultC = c.getIntegrityCompleteAnalysize(t);
            if(resultC!=null){
                iCCount++;
                reslist.add(resultC);
                //System.out.println(resultC);
            }
            ResultMessage resultL = utils.getIntegrityLogicAnalysize(t);
            if(resultL!=null){
                iLCont++;
                reslist.add(resultL);
                //System.out.println(resultL);
            }
        }
        final String uuId = utils.getUUId();
//       写入流
        utils.writeExcel(reslist,uuId);
        pt.setUId(uuId);
        pt.setResultms(reslist);
        pt.setIACount(iACount);
        pt.setICCount(iCCount);
        pt.setILCount(iLCont);
        return pt;
    }
}
